import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { Scoreboard, SportType } from '../backend';
import { toast } from 'sonner';

export function useGetAllScoreboards() {
  const { actor, isFetching } = useActor();

  return useQuery<Scoreboard[]>({
    queryKey: ['scoreboards'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllScoreboards();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 2000, // Poll every 2 seconds for real-time updates
  });
}

export function useGetScoreboard(id: bigint | null) {
  const { actor, isFetching } = useActor();

  return useQuery<Scoreboard | null>({
    queryKey: ['scoreboard', id?.toString()],
    queryFn: async () => {
      if (!actor || id === null) return null;
      return actor.getScoreboard(id);
    },
    enabled: !!actor && !isFetching && id !== null,
    refetchInterval: 1000, // Poll every second for live updates
  });
}

export function useCreateScoreboard() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ name, sportType }: { name: string; sportType: SportType }) => {
      if (!actor) throw new Error('Actor not initialized');
      return actor.createScoreboard(name, sportType);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scoreboards'] });
      toast.success('Scoreboard created successfully');
    },
    onError: (error) => {
      toast.error('Failed to create scoreboard: ' + error.message);
    },
  });
}

export function useUpdateBasketballScoreboard() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      id,
      teamAName,
      teamBName,
      teamAScore,
      teamBScore,
      currentQuarter,
      timer,
      isTimerRunning,
    }: {
      id: bigint;
      teamAName: string;
      teamBName: string;
      teamAScore: bigint;
      teamBScore: bigint;
      currentQuarter: bigint;
      timer: bigint;
      isTimerRunning: boolean;
    }) => {
      if (!actor) throw new Error('Actor not initialized');
      return actor.updateBasketballScoreboard(
        id,
        teamAName,
        teamBName,
        teamAScore,
        teamBScore,
        currentQuarter,
        timer,
        isTimerRunning
      );
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['scoreboard', variables.id.toString()] });
      queryClient.invalidateQueries({ queryKey: ['scoreboards'] });
    },
    onError: (error) => {
      toast.error('Failed to update scoreboard: ' + error.message);
    },
  });
}

export function useUpdateVolleyballScoreboard() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      id,
      teamAName,
      teamBName,
      teamASets,
      teamBSets,
      currentSetPointsA,
      currentSetPointsB,
      setHistoryA,
      setHistoryB,
    }: {
      id: bigint;
      teamAName: string;
      teamBName: string;
      teamASets: bigint;
      teamBSets: bigint;
      currentSetPointsA: bigint;
      currentSetPointsB: bigint;
      setHistoryA: bigint[];
      setHistoryB: bigint[];
    }) => {
      if (!actor) throw new Error('Actor not initialized');
      return actor.updateVolleyballScoreboard(
        id,
        teamAName,
        teamBName,
        teamASets,
        teamBSets,
        currentSetPointsA,
        currentSetPointsB,
        setHistoryA,
        setHistoryB
      );
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['scoreboard', variables.id.toString()] });
      queryClient.invalidateQueries({ queryKey: ['scoreboards'] });
    },
    onError: (error) => {
      toast.error('Failed to update scoreboard: ' + error.message);
    },
  });
}

export function useDeleteScoreboard() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: bigint) => {
      if (!actor) throw new Error('Actor not initialized');
      return actor.deleteScoreboard(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scoreboards'] });
      toast.success('Scoreboard deleted successfully');
    },
    onError: (error) => {
      toast.error('Failed to delete scoreboard: ' + error.message);
    },
  });
}
