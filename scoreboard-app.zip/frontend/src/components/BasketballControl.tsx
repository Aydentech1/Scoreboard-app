import { useState, useEffect } from 'react';
import type { Scoreboard, BasketballState } from '../backend';
import { useUpdateBasketballScoreboard } from '../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Plus, Minus, Play, Pause, RotateCcw } from 'lucide-react';
import { toast } from 'sonner';

interface BasketballControlProps {
  scoreboard: Scoreboard;
  state: BasketballState;
}

export function BasketballControl({ scoreboard, state }: BasketballControlProps) {
  const [teamAName, setTeamAName] = useState(state.teamAName);
  const [teamBName, setTeamBName] = useState(state.teamBName);
  const [teamAScore, setTeamAScore] = useState(Number(state.teamAScore));
  const [teamBScore, setTeamBScore] = useState(Number(state.teamBScore));
  const [currentQuarter, setCurrentQuarter] = useState(Number(state.currentQuarter));
  const [timer, setTimer] = useState(Number(state.timer));
  const [isTimerRunning, setIsTimerRunning] = useState(state.isTimerRunning);

  const updateScoreboard = useUpdateBasketballScoreboard();

  useEffect(() => {
    setTeamAName(state.teamAName);
    setTeamBName(state.teamBName);
    setTeamAScore(Number(state.teamAScore));
    setTeamBScore(Number(state.teamBScore));
    setCurrentQuarter(Number(state.currentQuarter));
    setTimer(Number(state.timer));
    setIsTimerRunning(state.isTimerRunning);
  }, [state]);

  useEffect(() => {
    if (!isTimerRunning) return;

    const interval = setInterval(() => {
      setTimer((prev) => {
        const newTimer = Math.max(0, prev - 1);
        if (newTimer === 0) {
          setIsTimerRunning(false);
          handleUpdate({ timer: BigInt(0), isTimerRunning: false });
        }
        return newTimer;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isTimerRunning]);

  const handleUpdate = async (updates: Partial<{
    teamAName: string;
    teamBName: string;
    teamAScore: bigint;
    teamBScore: bigint;
    currentQuarter: bigint;
    timer: bigint;
    isTimerRunning: boolean;
  }>) => {
    await updateScoreboard.mutateAsync({
      id: scoreboard.id,
      teamAName: updates.teamAName ?? teamAName,
      teamBName: updates.teamBName ?? teamBName,
      teamAScore: updates.teamAScore ?? BigInt(teamAScore),
      teamBScore: updates.teamBScore ?? BigInt(teamBScore),
      currentQuarter: updates.currentQuarter ?? BigInt(currentQuarter),
      timer: updates.timer ?? BigInt(timer),
      isTimerRunning: updates.isTimerRunning ?? isTimerRunning,
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">{scoreboard.name} - Control Panel</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Team Names */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="teamA">Team A Name</Label>
              <Input
                id="teamA"
                value={teamAName}
                onChange={(e) => setTeamAName(e.target.value)}
                onBlur={() => handleUpdate({ teamAName })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="teamB">Team B Name</Label>
              <Input
                id="teamB"
                value={teamBName}
                onChange={(e) => setTeamBName(e.target.value)}
                onBlur={() => handleUpdate({ teamBName })}
              />
            </div>
          </div>

          {/* Scores */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-chart-1/10 border-chart-1/20">
              <CardHeader>
                <CardTitle className="text-center">{teamAName}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-6xl font-black text-center text-chart-1">{teamAScore}</div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => {
                      const newScore = Math.max(0, teamAScore - 1);
                      setTeamAScore(newScore);
                      handleUpdate({ teamAScore: BigInt(newScore) });
                    }}
                    variant="outline"
                    size="lg"
                    className="flex-1"
                  >
                    <Minus className="w-5 h-5" />
                  </Button>
                  <Button
                    onClick={() => {
                      const newScore = teamAScore + 1;
                      setTeamAScore(newScore);
                      handleUpdate({ teamAScore: BigInt(newScore) });
                    }}
                    size="lg"
                    className="flex-1"
                  >
                    <Plus className="w-5 h-5" />
                  </Button>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[1, 2, 3].map((points) => (
                    <Button
                      key={points}
                      onClick={() => {
                        const newScore = teamAScore + points;
                        setTeamAScore(newScore);
                        handleUpdate({ teamAScore: BigInt(newScore) });
                      }}
                      variant="secondary"
                      size="sm"
                    >
                      +{points}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-chart-2/10 border-chart-2/20">
              <CardHeader>
                <CardTitle className="text-center">{teamBName}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-6xl font-black text-center text-chart-2">{teamBScore}</div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => {
                      const newScore = Math.max(0, teamBScore - 1);
                      setTeamBScore(newScore);
                      handleUpdate({ teamBScore: BigInt(newScore) });
                    }}
                    variant="outline"
                    size="lg"
                    className="flex-1"
                  >
                    <Minus className="w-5 h-5" />
                  </Button>
                  <Button
                    onClick={() => {
                      const newScore = teamBScore + 1;
                      setTeamBScore(newScore);
                      handleUpdate({ teamBScore: BigInt(newScore) });
                    }}
                    size="lg"
                    className="flex-1"
                  >
                    <Plus className="w-5 h-5" />
                  </Button>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[1, 2, 3].map((points) => (
                    <Button
                      key={points}
                      onClick={() => {
                        const newScore = teamBScore + points;
                        setTeamBScore(newScore);
                        handleUpdate({ teamBScore: BigInt(newScore) });
                      }}
                      variant="secondary"
                      size="sm"
                    >
                      +{points}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quarter Control */}
          <Card>
            <CardHeader>
              <CardTitle>Quarter</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <Button
                  onClick={() => {
                    const newQuarter = Math.max(1, currentQuarter - 1);
                    setCurrentQuarter(newQuarter);
                    handleUpdate({ currentQuarter: BigInt(newQuarter) });
                  }}
                  variant="outline"
                  size="lg"
                  disabled={currentQuarter <= 1}
                >
                  <Minus className="w-5 h-5" />
                </Button>
                <div className="flex-1 text-center">
                  <div className="text-5xl font-bold">{currentQuarter}</div>
                </div>
                <Button
                  onClick={() => {
                    const newQuarter = currentQuarter + 1;
                    setCurrentQuarter(newQuarter);
                    handleUpdate({ currentQuarter: BigInt(newQuarter) });
                  }}
                  variant="outline"
                  size="lg"
                >
                  <Plus className="w-5 h-5" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Timer Control */}
          <Card>
            <CardHeader>
              <CardTitle>Timer</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-5xl font-mono font-bold text-center">{formatTime(timer)}</div>
              <div className="flex gap-2">
                <Button
                  onClick={() => {
                    const newRunning = !isTimerRunning;
                    setIsTimerRunning(newRunning);
                    handleUpdate({ isTimerRunning: newRunning });
                  }}
                  size="lg"
                  className="flex-1"
                  variant={isTimerRunning ? 'secondary' : 'default'}
                >
                  {isTimerRunning ? (
                    <>
                      <Pause className="w-5 h-5 mr-2" />
                      Pause
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5 mr-2" />
                      Start
                    </>
                  )}
                </Button>
                <Button
                  onClick={() => {
                    setTimer(600);
                    setIsTimerRunning(false);
                    handleUpdate({ timer: BigInt(600), isTimerRunning: false });
                  }}
                  size="lg"
                  variant="outline"
                >
                  <RotateCcw className="w-5 h-5 mr-2" />
                  Reset (10:00)
                </Button>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {[60, 120, 300, 600].map((seconds) => (
                  <Button
                    key={seconds}
                    onClick={() => {
                      setTimer(seconds);
                      handleUpdate({ timer: BigInt(seconds) });
                    }}
                    variant="secondary"
                    size="sm"
                  >
                    {formatTime(seconds)}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
}
