import { useState, useEffect } from 'react';
import type { Scoreboard, VolleyballState } from '../backend';
import { useUpdateVolleyballScoreboard } from '../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Plus, Minus, RotateCcw } from 'lucide-react';
import { toast } from 'sonner';

interface VolleyballControlProps {
  scoreboard: Scoreboard;
  state: VolleyballState;
}

export function VolleyballControl({ scoreboard, state }: VolleyballControlProps) {
  const [teamAName, setTeamAName] = useState(state.teamAName);
  const [teamBName, setTeamBName] = useState(state.teamBName);
  const [teamASets, setTeamASets] = useState(Number(state.teamASets));
  const [teamBSets, setTeamBSets] = useState(Number(state.teamBSets));
  const [currentSetPointsA, setCurrentSetPointsA] = useState(Number(state.currentSetPointsA));
  const [currentSetPointsB, setCurrentSetPointsB] = useState(Number(state.currentSetPointsB));
  const [setHistoryA, setSetHistoryA] = useState<number[]>(state.setHistoryA.map(Number));
  const [setHistoryB, setSetHistoryB] = useState<number[]>(state.setHistoryB.map(Number));

  const updateScoreboard = useUpdateVolleyballScoreboard();

  useEffect(() => {
    setTeamAName(state.teamAName);
    setTeamBName(state.teamBName);
    setTeamASets(Number(state.teamASets));
    setTeamBSets(Number(state.teamBSets));
    setCurrentSetPointsA(Number(state.currentSetPointsA));
    setCurrentSetPointsB(Number(state.currentSetPointsB));
    setSetHistoryA(state.setHistoryA.map(Number));
    setSetHistoryB(state.setHistoryB.map(Number));
  }, [state]);

  const handleUpdate = async (updates: Partial<{
    teamAName: string;
    teamBName: string;
    teamASets: bigint;
    teamBSets: bigint;
    currentSetPointsA: bigint;
    currentSetPointsB: bigint;
    setHistoryA: bigint[];
    setHistoryB: bigint[];
  }>) => {
    await updateScoreboard.mutateAsync({
      id: scoreboard.id,
      teamAName: updates.teamAName ?? teamAName,
      teamBName: updates.teamBName ?? teamBName,
      teamASets: updates.teamASets ?? BigInt(teamASets),
      teamBSets: updates.teamBSets ?? BigInt(teamBSets),
      currentSetPointsA: updates.currentSetPointsA ?? BigInt(currentSetPointsA),
      currentSetPointsB: updates.currentSetPointsB ?? BigInt(currentSetPointsB),
      setHistoryA: updates.setHistoryA ?? setHistoryA.map(BigInt),
      setHistoryB: updates.setHistoryB ?? setHistoryB.map(BigInt),
    });
  };

  const finishSet = (winner: 'A' | 'B') => {
    const newHistoryA = [...setHistoryA, currentSetPointsA];
    const newHistoryB = [...setHistoryB, currentSetPointsB];
    const newSetsA = winner === 'A' ? teamASets + 1 : teamASets;
    const newSetsB = winner === 'B' ? teamBSets + 1 : teamBSets;

    setSetHistoryA(newHistoryA);
    setSetHistoryB(newHistoryB);
    setTeamASets(newSetsA);
    setTeamBSets(newSetsB);
    setCurrentSetPointsA(0);
    setCurrentSetPointsB(0);

    handleUpdate({
      setHistoryA: newHistoryA.map(BigInt),
      setHistoryB: newHistoryB.map(BigInt),
      teamASets: BigInt(newSetsA),
      teamBSets: BigInt(newSetsB),
      currentSetPointsA: BigInt(0),
      currentSetPointsB: BigInt(0),
    });

    toast.success(`${winner === 'A' ? teamAName : teamBName} wins the set!`);
  };

  const resetCurrentSet = () => {
    setCurrentSetPointsA(0);
    setCurrentSetPointsB(0);
    handleUpdate({
      currentSetPointsA: BigInt(0),
      currentSetPointsB: BigInt(0),
    });
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">{scoreboard.name} - Control Panel</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Team Names */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="teamA">Team A Name</Label>
              <Input
                id="teamA"
                value={teamAName}
                onChange={(e) => setTeamAName(e.target.value)}
                onBlur={() => handleUpdate({ teamAName })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="teamB">Team B Name</Label>
              <Input
                id="teamB"
                value={teamBName}
                onChange={(e) => setTeamBName(e.target.value)}
                onBlur={() => handleUpdate({ teamBName })}
              />
            </div>
          </div>

          {/* Sets Won */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-chart-3/10 border-chart-3/20">
              <CardHeader>
                <CardTitle className="text-center">{teamAName}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-2">Sets Won</p>
                  <div className="text-5xl font-black text-chart-3">{teamASets}</div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-chart-4/10 border-chart-4/20">
              <CardHeader>
                <CardTitle className="text-center">{teamBName}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-2">Sets Won</p>
                  <div className="text-5xl font-black text-chart-4">{teamBSets}</div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Current Set Points */}
          <Card>
            <CardHeader>
              <CardTitle>Current Set - Points</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-muted-foreground mb-2">{teamAName}</p>
                    <div className="text-6xl font-black text-chart-3">{currentSetPointsA}</div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => {
                        const newPoints = Math.max(0, currentSetPointsA - 1);
                        setCurrentSetPointsA(newPoints);
                        handleUpdate({ currentSetPointsA: BigInt(newPoints) });
                      }}
                      variant="outline"
                      size="lg"
                      className="flex-1"
                    >
                      <Minus className="w-5 h-5" />
                    </Button>
                    <Button
                      onClick={() => {
                        const newPoints = currentSetPointsA + 1;
                        setCurrentSetPointsA(newPoints);
                        handleUpdate({ currentSetPointsA: BigInt(newPoints) });
                      }}
                      size="lg"
                      className="flex-1"
                    >
                      <Plus className="w-5 h-5" />
                    </Button>
                  </div>
                  <Button
                    onClick={() => finishSet('A')}
                    className="w-full"
                    variant="default"
                  >
                    {teamAName} Wins Set
                  </Button>
                </div>

                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-muted-foreground mb-2">{teamBName}</p>
                    <div className="text-6xl font-black text-chart-4">{currentSetPointsB}</div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => {
                        const newPoints = Math.max(0, currentSetPointsB - 1);
                        setCurrentSetPointsB(newPoints);
                        handleUpdate({ currentSetPointsB: BigInt(newPoints) });
                      }}
                      variant="outline"
                      size="lg"
                      className="flex-1"
                    >
                      <Minus className="w-5 h-5" />
                    </Button>
                    <Button
                      onClick={() => {
                        const newPoints = currentSetPointsB + 1;
                        setCurrentSetPointsB(newPoints);
                        handleUpdate({ currentSetPointsB: BigInt(newPoints) });
                      }}
                      size="lg"
                      className="flex-1"
                    >
                      <Plus className="w-5 h-5" />
                    </Button>
                  </div>
                  <Button
                    onClick={() => finishSet('B')}
                    className="w-full"
                    variant="default"
                  >
                    {teamBName} Wins Set
                  </Button>
                </div>
              </div>

              <Button
                onClick={resetCurrentSet}
                variant="outline"
                className="w-full"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset Current Set
              </Button>
            </CardContent>
          </Card>

          {/* Set History */}
          {setHistoryA.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Set History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {setHistoryA.map((_, index) => (
                    <div key={index} className="grid grid-cols-3 gap-4 items-center p-3 bg-muted/50 rounded-lg">
                      <div className="text-right text-2xl font-bold text-chart-3">
                        {setHistoryA[index]}
                      </div>
                      <div className="text-center text-muted-foreground font-medium">
                        Set {index + 1}
                      </div>
                      <div className="text-left text-2xl font-bold text-chart-4">
                        {setHistoryB[index]}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
