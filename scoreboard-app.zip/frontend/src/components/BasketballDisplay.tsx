import type { Scoreboard, BasketballState } from '../backend';
import { useEffect, useState } from 'react';

interface BasketballDisplayProps {
  scoreboard: Scoreboard;
  state: BasketballState;
}

export function BasketballDisplay({ scoreboard, state }: BasketballDisplayProps) {
  const [displayTimer, setDisplayTimer] = useState(Number(state.timer));

  useEffect(() => {
    setDisplayTimer(Number(state.timer));
  }, [state.timer]);

  useEffect(() => {
    if (!state.isTimerRunning) return;

    const interval = setInterval(() => {
      setDisplayTimer((prev) => Math.max(0, prev - 1));
    }, 1000);

    return () => clearInterval(interval);
  }, [state.isTimerRunning]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-chart-1/10 via-background to-chart-2/10">
      <div className="w-full max-w-6xl space-y-8">
        {/* Game Title */}
        <div className="text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-2">{scoreboard.name}</h1>
          <p className="text-xl text-muted-foreground">Basketball</p>
        </div>

        {/* Main Scoreboard */}
        <div className="grid grid-cols-2 gap-8">
          {/* Team A */}
          <div className="bg-gradient-to-br from-chart-1 to-chart-1/80 rounded-3xl p-8 shadow-2xl">
            <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-6 truncate">
              {state.teamAName}
            </h2>
            <div className="text-8xl md:text-9xl font-black text-white text-center">
              {state.teamAScore.toString()}
            </div>
          </div>

          {/* Team B */}
          <div className="bg-gradient-to-br from-chart-2 to-chart-2/80 rounded-3xl p-8 shadow-2xl">
            <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-6 truncate">
              {state.teamBName}
            </h2>
            <div className="text-8xl md:text-9xl font-black text-white text-center">
              {state.teamBScore.toString()}
            </div>
          </div>
        </div>

        {/* Game Info */}
        <div className="grid grid-cols-2 gap-6">
          <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-border/50">
            <p className="text-muted-foreground text-center mb-2 text-lg">Quarter</p>
            <p className="text-5xl font-bold text-center text-foreground">
              {state.currentQuarter.toString()}
            </p>
          </div>
          <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-border/50">
            <p className="text-muted-foreground text-center mb-2 text-lg">Time</p>
            <p className="text-5xl font-bold text-center text-foreground font-mono">
              {formatTime(displayTimer)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
