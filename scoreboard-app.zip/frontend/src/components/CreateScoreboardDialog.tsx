import { useState } from 'react';
import { useCreateScoreboard } from '../hooks/useQueries';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Plus } from 'lucide-react';
import { SportType } from '../backend';

export function CreateScoreboardDialog() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [sportType, setSportType] = useState<SportType>(SportType.basketball);
  const createScoreboard = useCreateScoreboard();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    await createScoreboard.mutateAsync({ name: name.trim(), sportType });
    setName('');
    setSportType(SportType.basketball);
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" className="shadow-lg">
          <Plus className="w-5 h-5 mr-2" />
          New Scoreboard
        </Button>
      </DialogTrigger>
      <DialogContent>
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Create New Scoreboard</DialogTitle>
            <DialogDescription>
              Set up a new scoreboard for basketball or volleyball
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Scoreboard Name</Label>
              <Input
                id="name"
                placeholder="e.g., Championship Game"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sport">Sport Type</Label>
              <Select
                value={sportType}
                onValueChange={(value) => setSportType(value as SportType)}
              >
                <SelectTrigger id="sport">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={SportType.basketball}>🏀 Basketball</SelectItem>
                  <SelectItem value={SportType.volleyball}>🏐 Volleyball</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={createScoreboard.isPending || !name.trim()}>
              {createScoreboard.isPending ? 'Creating...' : 'Create'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
