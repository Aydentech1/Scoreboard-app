import type { Scoreboard, VolleyballState } from '../backend';

interface VolleyballDisplayProps {
  scoreboard: Scoreboard;
  state: VolleyballState;
}

export function VolleyballDisplay({ scoreboard, state }: VolleyballDisplayProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-chart-3/10 via-background to-chart-4/10">
      <div className="w-full max-w-6xl space-y-8">
        {/* Game Title */}
        <div className="text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-2">{scoreboard.name}</h1>
          <p className="text-xl text-muted-foreground">Volleyball</p>
        </div>

        {/* Sets Won */}
        <div className="grid grid-cols-2 gap-8">
          <div className="bg-gradient-to-br from-chart-3 to-chart-3/80 rounded-3xl p-6 shadow-2xl">
            <h2 className="text-2xl md:text-3xl font-bold text-white text-center mb-3 truncate">
              {state.teamAName}
            </h2>
            <p className="text-sm text-white/80 text-center mb-2">Sets Won</p>
            <div className="text-6xl md:text-7xl font-black text-white text-center">
              {state.teamASets.toString()}
            </div>
          </div>

          <div className="bg-gradient-to-br from-chart-4 to-chart-4/80 rounded-3xl p-6 shadow-2xl">
            <h2 className="text-2xl md:text-3xl font-bold text-white text-center mb-3 truncate">
              {state.teamBName}
            </h2>
            <p className="text-sm text-white/80 text-center mb-2">Sets Won</p>
            <div className="text-6xl md:text-7xl font-black text-white text-center">
              {state.teamBSets.toString()}
            </div>
          </div>
        </div>

        {/* Current Set Points */}
        <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg border border-border/50">
          <h3 className="text-2xl font-bold text-center mb-6 text-foreground">Current Set</h3>
          <div className="grid grid-cols-2 gap-8">
            <div className="text-center">
              <p className="text-muted-foreground mb-2 text-lg">{state.teamAName}</p>
              <p className="text-7xl font-black text-chart-3">{state.currentSetPointsA.toString()}</p>
            </div>
            <div className="text-center">
              <p className="text-muted-foreground mb-2 text-lg">{state.teamBName}</p>
              <p className="text-7xl font-black text-chart-4">{state.currentSetPointsB.toString()}</p>
            </div>
          </div>
        </div>

        {/* Set History */}
        {state.setHistoryA.length > 0 && (
          <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-border/50">
            <h3 className="text-xl font-bold text-center mb-4 text-foreground">Set History</h3>
            <div className="space-y-2">
              {state.setHistoryA.map((_, index) => (
                <div key={index} className="grid grid-cols-3 gap-4 items-center">
                  <div className="text-right text-2xl font-bold text-chart-3">
                    {state.setHistoryA[index].toString()}
                  </div>
                  <div className="text-center text-muted-foreground font-medium">
                    Set {index + 1}
                  </div>
                  <div className="text-left text-2xl font-bold text-chart-4">
                    {state.setHistoryB[index].toString()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
