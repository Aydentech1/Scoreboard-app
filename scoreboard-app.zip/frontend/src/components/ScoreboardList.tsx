import { useGetAllScoreboards, useDeleteScoreboard } from '../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Monitor, Gamepad2, Trash2, Trophy } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import { SportType } from '../backend';

interface ScoreboardListProps {
  onSelectScoreboard: (id: bigint, mode: 'display' | 'control') => void;
}

export function ScoreboardList({ onSelectScoreboard }: ScoreboardListProps) {
  const { data: scoreboards, isLoading } = useGetAllScoreboards();
  const deleteScoreboard = useDeleteScoreboard();

  if (isLoading) {
    return (
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-6 bg-muted rounded w-3/4" />
              <div className="h-4 bg-muted rounded w-1/2 mt-2" />
            </CardHeader>
            <CardContent>
              <div className="h-10 bg-muted rounded" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!scoreboards || scoreboards.length === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="flex flex-col items-center justify-center py-16 text-center">
          <Trophy className="w-16 h-16 text-muted-foreground/50 mb-4" />
          <h3 className="text-lg font-semibold mb-2">No scoreboards yet</h3>
          <p className="text-muted-foreground mb-4">Create your first scoreboard to get started</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {scoreboards.map((scoreboard) => (
        <Card key={scoreboard.id.toString()} className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <CardTitle className="text-xl">{scoreboard.name}</CardTitle>
                <CardDescription className="mt-1">
                  {scoreboard.sportType === SportType.basketball ? 'Basketball' : 'Volleyball'}
                </CardDescription>
              </div>
              <Badge variant="secondary" className="ml-2">
                {scoreboard.sportType === SportType.basketball ? '🏀' : '🏐'}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex gap-2">
              <Button
                onClick={() => onSelectScoreboard(scoreboard.id, 'display')}
                className="flex-1"
                variant="default"
              >
                <Monitor className="w-4 h-4 mr-2" />
                Display
              </Button>
              <Button
                onClick={() => onSelectScoreboard(scoreboard.id, 'control')}
                className="flex-1"
                variant="secondary"
              >
                <Gamepad2 className="w-4 h-4 mr-2" />
                Control
              </Button>
            </div>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="sm" className="w-full">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Scoreboard</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete "{scoreboard.name}"? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => deleteScoreboard.mutate(scoreboard.id)}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
