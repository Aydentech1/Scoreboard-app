import { useGetScoreboard } from '../hooks/useQueries';
import { BasketballDisplay } from './BasketballDisplay';
import { VolleyballDisplay } from './VolleyballDisplay';

interface ScoreboardDisplayProps {
  scoreboardId: bigint;
}

export function ScoreboardDisplay({ scoreboardId }: ScoreboardDisplayProps) {
  const { data: scoreboard, isLoading } = useGetScoreboard(scoreboardId);

  if (isLoading || !scoreboard) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-muted-foreground">Loading scoreboard...</p>
        </div>
      </div>
    );
  }

  if (scoreboard.state.__kind__ === 'basketball') {
    return <BasketballDisplay scoreboard={scoreboard} state={scoreboard.state.basketball} />;
  } else {
    return <VolleyballDisplay scoreboard={scoreboard} state={scoreboard.state.volleyball} />;
  }
}
