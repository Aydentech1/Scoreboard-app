import { useGetScoreboard } from '../hooks/useQueries';
import { BasketballControl } from './BasketballControl';
import { VolleyballControl } from './VolleyballControl';
import { Card, CardContent } from './ui/card';

interface ScoreboardControlProps {
  scoreboardId: bigint;
}

export function ScoreboardControl({ scoreboardId }: ScoreboardControlProps) {
  const { data: scoreboard, isLoading } = useGetScoreboard(scoreboardId);

  if (isLoading || !scoreboard) {
    return (
      <Card>
        <CardContent className="py-16 text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading controls...</p>
        </CardContent>
      </Card>
    );
  }

  if (scoreboard.state.__kind__ === 'basketball') {
    return <BasketballControl scoreboard={scoreboard} state={scoreboard.state.basketball} />;
  } else {
    return <VolleyballControl scoreboard={scoreboard} state={scoreboard.state.volleyball} />;
  }
}
