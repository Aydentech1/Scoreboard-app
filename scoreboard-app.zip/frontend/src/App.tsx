import { useState } from 'react';
import { useActor } from './hooks/useActor';
import { ScoreboardList } from './components/ScoreboardList';
import { CreateScoreboardDialog } from './components/CreateScoreboardDialog';
import { ScoreboardDisplay } from './components/ScoreboardDisplay';
import { ScoreboardControl } from './components/ScoreboardControl';
import { Button } from './components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { Toaster } from './components/ui/sonner';
import { ThemeProvider } from 'next-themes';

type ViewMode = 'list' | 'display' | 'control';

function App() {
  const { actor } = useActor();
  const [selectedScoreboardId, setSelectedScoreboardId] = useState<bigint | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('list');

  const handleSelectScoreboard = (id: bigint, mode: 'display' | 'control') => {
    setSelectedScoreboardId(id);
    setViewMode(mode);
  };

  const handleBackToList = () => {
    setSelectedScoreboardId(null);
    setViewMode('list');
  };

  if (!actor) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-accent/5">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
        {viewMode === 'list' ? (
          <>
            <header className="border-b border-border/40 bg-card/50 backdrop-blur-sm sticky top-0 z-10">
              <div className="container mx-auto px-4 py-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-chart-1 bg-clip-text text-transparent">
                      Scoreboard App
                    </h1>
                    <p className="text-muted-foreground mt-1">Manage basketball and volleyball scoreboards</p>
                  </div>
                  <CreateScoreboardDialog />
                </div>
              </div>
            </header>
            <main className="container mx-auto px-4 py-8">
              <ScoreboardList onSelectScoreboard={handleSelectScoreboard} />
            </main>
          </>
        ) : viewMode === 'display' && selectedScoreboardId !== null ? (
          <div className="min-h-screen">
            <div className="absolute top-4 left-4 z-10">
              <Button
                onClick={handleBackToList}
                variant="secondary"
                size="sm"
                className="shadow-lg"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to List
              </Button>
            </div>
            <ScoreboardDisplay scoreboardId={selectedScoreboardId} />
          </div>
        ) : viewMode === 'control' && selectedScoreboardId !== null ? (
          <div className="min-h-screen">
            <header className="border-b border-border/40 bg-card/50 backdrop-blur-sm sticky top-0 z-10">
              <div className="container mx-auto px-4 py-4">
                <Button
                  onClick={handleBackToList}
                  variant="ghost"
                  size="sm"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to List
                </Button>
              </div>
            </header>
            <main className="container mx-auto px-4 py-8">
              <ScoreboardControl scoreboardId={selectedScoreboardId} />
            </main>
          </div>
        ) : null}
        <footer className="border-t border-border/40 bg-card/30 backdrop-blur-sm mt-auto py-6">
          <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
            © 2025. Built with love using{' '}
            <a
              href="https://caffeine.ai"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline font-medium"
            >
              caffeine.ai
            </a>
          </div>
        </footer>
      </div>
      <Toaster />
    </ThemeProvider>
  );
}

export default App;
